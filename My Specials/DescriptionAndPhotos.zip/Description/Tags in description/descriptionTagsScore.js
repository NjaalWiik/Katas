const descriptionTagsScore = integer => integer > 2;

descriptionTagsScore(3);
descriptionTagsScore(2);
