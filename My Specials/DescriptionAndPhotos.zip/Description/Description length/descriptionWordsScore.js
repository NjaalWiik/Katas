const descriptionWordsScore = integer => integer >= 160;

descriptionWordsScore(159);
descriptionWordsScore(160);
