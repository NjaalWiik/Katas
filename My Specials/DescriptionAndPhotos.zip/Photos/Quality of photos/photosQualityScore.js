const photosQualityScore = integer => integer === 0;

photosQualityScore(0);
photosQualityScore(1);
