const photosNbrScore = integer => integer >= 6;

photosNbrScore(5);
photosNbrScore(6);
